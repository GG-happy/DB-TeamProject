package edu.deu.dbprogramming.DBP_financeMgmt_Team11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbpFinanceMgmtTeam11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
