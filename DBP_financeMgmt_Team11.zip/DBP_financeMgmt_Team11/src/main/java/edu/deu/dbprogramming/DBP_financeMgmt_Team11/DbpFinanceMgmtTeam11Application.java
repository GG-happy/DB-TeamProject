package edu.deu.dbprogramming.DBP_financeMgmt_Team11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbpFinanceMgmtTeam11Application {

	public static void main(String[] args) {
		SpringApplication.run(DbpFinanceMgmtTeam11Application.class, args);
	}

}
